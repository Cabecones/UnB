# Trabalho 2

Depois de clonar o repositório, você pode executar o seguinte comando para instalar as dependencies necessárias:

```pip install -r requirements.txt```

Após isso, só rodar normalmente o código e os testes.

